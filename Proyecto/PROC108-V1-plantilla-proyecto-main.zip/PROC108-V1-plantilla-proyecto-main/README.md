# PROC108-V1-plantilla-proyecto
Reconocimiento de gestos de mano.  
Python. MediaPipe.  
  
Gestos de me gusta y no me gusta.  
  
### Texto en inglés: PRO-C108-Project-Template
project template for c108
